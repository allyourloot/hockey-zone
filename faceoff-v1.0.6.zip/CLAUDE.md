# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Development Commands

**Running the game:**
```bash
bun run index.ts
```

**No build/test/lint commands are configured** - this is a runtime-only project using Bun and TypeScript with the Hytopia SDK.

**TypeScript compilation:**
The project uses TypeScript with `noEmit: true` in tsconfig.json, so no compilation step is needed. Type checking is handled by the editor/IDE.

## Architecture Overview

This is a **3D multiplayer hockey game** built with the Hytopia SDK. The codebase follows a **service-oriented architecture** with clear separation of concerns:

### Core Architecture Patterns

- **Singleton Managers**: All managers use singleton pattern for centralized state management
- **Service Layer**: Specialized services handle complex game mechanics (goal detection, offside detection, etc.)
- **Entity-Component-System**: Leverages Hytopia's ECS architecture for game entities
- **Event-Driven Design**: Managers communicate through events and callbacks

### Key Systems

**Game State Management:**
- `HockeyGameManager` - Central game state machine (lobby → team selection → match → game over)
- `PlayerManager` - Player lifecycle, UI management, team assignment
- `PlayerSpawnManager` - Team/position-based spawn system with validation

**Game Mechanics:**
- `GoalDetectionService` - Coordinate-based goal detection with assist tracking
- `OffsideDetectionService` - NHL-style offside detection (immediate and delayed)
- `PlayerBarrierService` - Prevents players from entering restricted areas
- `PuckBoundaryService` - Automatic puck respawn when out of bounds

**Audio & Effects:**
- `AudioManager` - Audio pooling system for performance optimization
- `PuckTrailManager` - Visual puck trail effects
- `PuckControlIndicatorService` - UI indicators for puck control

**Player Systems:**
- `IceSkatingController` - Realistic ice skating physics and puck control
- `PlayerStatsManager` - Live statistics tracking (goals, assists, saves)
- `AFKManager` - Automatic handling of inactive players

### Directory Structure

```
classes/
├── managers/        # Singleton managers for core systems
├── services/        # Specialized game rule services  
├── controllers/     # Entity behavior controllers
├── systems/         # World/environment initialization
├── entities/        # Custom game entities
└── utils/          # Shared constants and types
```

## Important Implementation Notes

**Hytopia SDK Integration:**
- Always use the Hytopia MCP Server tools for SDK help and examples
- Use `read_me_first` tool for general Hytopia development tips
- Use `full_game_example` tool for complete implementation examples
- Must use help tools for specific SDK sections before implementing

**Asset Management:**
- Extensive audio library in `assets/audio/` (hockey sounds, crowd, music)
- 3D models for players, equipment, and game objects in `assets/models/`
- Hockey rink map and textures in `assets/maps/` and `assets/blocks/`
- UI assets and overlays in `assets/ui/`

**Game State Flow:**
1. Players join lobby → team selection → position selection → match start
2. 3-period hockey matches with automatic transitions
3. Real-time goal detection, offside detection, and statistics tracking
4. Professional game over sequences with winner announcements

**Performance Considerations:**
- Audio pooling system for efficient sound management
- Monitoring loops run at optimized intervals (goal detection: 50ms, offside: 100ms)
- Entity cleanup and resource management on shutdown

**Development Workflow:**
- No build step required - direct TypeScript execution with Bun
- Use chat commands for testing game mechanics (`/testgamestart`, `/goalred`, etc.)
- Debug logging system with specialized filters for different components
- Console debugging helpers for audio, entities, and cleanup

**Critical Services:**
- Goal detection uses coordinate-based collision detection with goal line crossing
- Offside detection implements full NHL rules with delayed offside logic
- Player barriers prevent inappropriate goal area access while allowing goalie movement
- Statistics system tracks comprehensive player and team performance metrics

The codebase prioritizes authentic hockey gameplay with professional-grade game management, making it essential to understand hockey rules and game flow when making modifications.